import random
import time
import logging
from typing import List
#
# Configuración del logger
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class desmont_ebl:
    def desmont_ebl("desmont_ebl")
class ec2:
    """"configuracion de spacio para ec2 instances, creando métodos y elaborando un elastic load balancing para su ejecución dentro de una red VPC)""""
    def __init__(id,instance, cpu_capacity: int, memory_capacity: int):
        self.instance=[]
        self.cpu_capacity = cpu_capacity
        self.memory_capacity = memory_capacity
        self.id = id
        self.cpu_capacity = cpu_capacity
        self.memory_capacity = memory_capacity
        self.cpu_usage = 0
        self.memory_usage = 0
    def recuperar(self,instance):
        print (f"recuperando {instance}"
    def iniciar(self,instance):
        self.iniciar=f"iniciando instancias {instance}"
    def detener(self,instancia):
        
        print(f"deteniendo instancias {instance}")
        
    def terminar(self,instance):
        print(f" terminando instancias {instance}")
    def desmont_ebl(self,instance):
        print(f" desmont  ebl {volume_ebl}

    def simulate_load(self):
        """Simula la carga en las instancias ec2"""
        self.cpu_usage = random.uniform(0, self.cpu_capacity)
        self.memory_usage = random.uniform(0, self.memory_capacity)

    def __repr__(self):
        return f"ec2(id={self.id}, cpu_usage={self.cpu_usage:.2f}/{self.cpu_capacity}, memory_usage={self.memory_usage:.2f}/{self.memory_capacity})"

class AutoScalingGroup:
    """verificar el tamaño del grupo de instancias ec2, y añadiendo funciones de añadir , remover , terminar y detener y adjuntar o desmontar volumnenes ebs"""
    def __init__(self, ec2_template: ec2_template, min_size: int, max_size: int):
        self.ec2 = ec2
        self.min_size = min_size
        self.max_size = max_size
        self.ec2 = [ec2_template.create_ec2(i) for i in range(min_size)]
        self.scaling_policy = self.default_scaling_policy

    def add_ec2_instance(self):
        """Añade un nuevo instancia al grupo"""
        if len(self.ec2) < self.max_size:
            new_ec2_template = self.ec2_template.create_ec2(len(self.ec2_instances))
            self.ec2.append(new_ec2)
            logging.info(f'instancia añadido: {new_ec2_template.id}')
        else:
            logging.info('El grupo ha alcanzado el tamaño máximo. No se pueden añadir más servidores.')
    def ended_ec2_instance(self):
        """Añade un nuevo instancia al grupo"""
        if len(self.ec2) < self.max_size:
            ended_ec2 = self.ec2_template.ended_ec2(len(self.ec2_instances))
            self.ec2.ended(ended_ec2)
            logging.info(f'instancia ended: {ended_ec2.id}')
        else:
            logging.info('El grupo ha alcanzado el tamaño máximo. No se pueden finalizar más servidores.')
    def detener_ec2_instance(self):
        """Añade un nuevo instancia al grupo"""
        if len(self.ec2) < self.max_size:
            stopped_ec2 = self.ec2_template.stopped_ec2(len(self.ec2_instances))
            self.ec2.stopped(stopped_ec2)
            logging.info(f'stopped instance: {stopped_ec2.id}')
        else:
            logging.info('El grupo ha alcanzado el tamaño máximo. No se pueden detener más servidores.')


    def remove_ec2(self):
        """Elimina el servidor menos ocupado del grupo"""
        if len(self.servers) > self.min_size:
            ec2_remove = min(self.ec2_template.remove, key=lambda s: s.cpu_usage + s.memory_usage)
            self.ec2.remove(ec2_remove)
            logging.info(f'ec2 instance suprimido: {ec2_remove.id}')
        else:
            logging.info('El grupo ha alcanzado el tamaño mínimo. No se pueden eliminar más servidores.')
    def desmontar_volumenes_ebl_instance(self):
        """Añade un nuevo instancia al grupo"""
        if len(self.ec2) < self.max_size:
            ebl_desmont= self.ec2_template.desmont_ebl_volume(len(self.ec2_instances))
            self.ec2.desmont_ebl(ec2_instance)
            logging.info(f'Servidor añadido: {new_server.id}')
        else:
            logging.info('El grupo ha alcanzado el tamaño máximo. No se pueden añadir más servidores.')
    def default_scaling_policy(self):
        """Política de escalado basada en uso de CPU y memoria"""
        avg_cpu_usage = sum(ec2.cpu_usage for ec2_instances in self.ec2_instances) / len(self.ec2_instances)
        avg_memory_usage = sum(ec2.memory_usage for ec2 in self.ec2_instances) / len(self.ec2_instances)
        logging.info(f'Métricas promedio - CPU: {avg_cpu_usage:.2f}%, Memoria: {avg_memory_usage:.2f}%')

        if avg_cpu_usage > 70 or avg_memory_usage > 70:
            self.add_ec2()
        elif avg_cpu_usage < 30 and avg_memory_usage < 30:
            self.remove_ec2()

    def set_scaling_policy(self, policy_function):
        """Define una política de escalado personalizada"""
        self.scaling_policy = policy_function

    def simulate_load(self):
        """Simula la carga en el grupo de ec2_instances"""
        for server in self.servers:
            server.simulate_load()

    def adjust_capacity(self):
        """Ajusta la capacidad del grupo de ec2_instances según la política de escalado"""
        self.simulate_load()
        self.scaling_policy()

class LoadSimulator:
    def __init__(self, auto_scaling_group: AutoScalingGroup):
        self.auto_scaling_group = auto_scaling_group

    def simulate_traffic(self, duration: int):
        """Simula tráfico variable durante un periodo de tiempo"""
        start_time = time.time()
        while time.time() - start_time < duration:
            self.auto_scaling_group.adjust_capacity()
            logging.info(f'Estado del grupo de ec2_instances: {self.auto_scaling_group.ec2_instances}')
            time.sleep(1)

# Definir una plantilla de servidor
ec2_template = ec2Template(cpu_capacity=100, memory_capacity=100)

# Crear un grupo de autoescalado con la plantilla de servidor
auto_scaling_group = AutoScalingGroup(ec2_template, min_size=2, max_size=5)

# Crear simulador de carga
load_simulator = LoadSimulator(auto_scaling_group)

# Simular tráfico variable durante 30 segundos
load_simulator.simulate_traffic(duration=30)
