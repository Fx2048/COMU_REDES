import logging
import random
import time

# Configuración del logger
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class Server:
    def __init__(self, id: int, cpu_capacity: int, memory_capacity: int):
        self.id = id
        self.cpu_capacity = cpu_capacity
        self.memory_capacity = memory_capacity
        self.current_load = 0

    def handle_request(self, load: int):
        """Simula el manejo de una solicitud en el servidor"""
        if self.current_load + load <= self.cpu_capacity:
            self.current_load += load
            logging.info(f'Servidor {self.id} manejando solicitud. Carga actual: {self.current_load}')
        else:
            logging.warning(f'Servidor {self.id} sobrecargado. Carga actual: {self.current_load}')

    def scale_up(self, additional_cpu: int, additional_memory: int):
        """Escala verticalmente el servidor agregando más capacidad de CPU y memoria"""
        self.cpu_capacity += additional_cpu
        self.memory_capacity += additional_memory
        logging.info(f'Servidor {self.id} escalado verticalmente. Nueva capacidad de CPU: {self.cpu_capacity}, Memoria: {self.memory_capacity}')

    def __repr__(self):
        return f"Server(id={self.id}, cpu_capacity={self.cpu_capacity}, memory_capacity={self.memory_capacity}, current_load={self.current_load})"

class ServerCluster:
    def __init__(self):
        self.servers = []

    def add_server(self, server: Server):
        """Añade un servidor al clúster"""
        self.servers.append(server)
        logging.info(f'Servidor añadido: {server.id}')

    def remove_server(self, server: Server):
        """Elimina un servidor del clúster"""
        self.servers.remove(server)
        logging.info(f'Servidor eliminado: {server.id}')

    def distribute_load(self, load: int):
        """Distribuye la carga entre los servidores disponibles"""
        if not self.servers:
            logging.error('No hay servidores disponibles para manejar la solicitud')
            return
        server = min(self.servers, key=lambda s: s.current_load)
        server.handle_request(load)

    def __repr__(self):
        return f"ServerCluster(servers={self.servers})"

class AutoScaler:
    def __init__(self, cluster: ServerCluster, cpu_threshold: float, memory_threshold: float):
        self.cluster = cluster
        self.cpu_threshold = cpu_threshold
        self.memory_threshold = memory_threshold

    def scale(self):
        """Ajusta automáticamente la capacidad del clúster"""
        total_cpu_capacity = sum(server.cpu_capacity for server in self.cluster.servers)
        total_memory_capacity = sum(server.memory_capacity for server in self.cluster.servers)
        total_load = sum(server.current_load for server in self.cluster.servers)

        cpu_utilization = total_load / total_cpu_capacity
        logging.info(f'Utilización de CPU: {cpu_utilization:.2f}')
        
        if cpu_utilization > self.cpu_threshold:
            new_server = Server(id=len(self.cluster.servers) + 1, cpu_capacity=100, memory_capacity=100)
            self.cluster.add_server(new_server)
            logging.info(f'Escalado horizontal: Añadido servidor {new_server.id}')
        elif cpu_utilization < (self.cpu_threshold / 2) and len(self.cluster.servers) > 1:
            server_to_remove = self.cluster.servers[-1]
            self.cluster.remove_server(server_to_remove)
            logging.info(f'Escalado horizontal: Eliminado servidor {server_to_remove.id}')

class TrafficSimulator:
    def __init__(self, cluster: ServerCluster, auto_scaler: AutoScaler):
        self.cluster = cluster
        self.auto_scaler = auto_scaler

    def simulate_traffic(self, duration: int):
        """Simula la llegada de solicitudes durante un periodo de tiempo"""
        start_time = time.time()
        while time.time() - start_time < duration:
            load = random.randint(1, 50)
            self.cluster.distribute_load(load)
            self.auto_scaler.scale()
            time.sleep(1)


class WebApplicationFirewall:
    """Clase que representa un firewall para aplicaciones web."""
    def __init__(self):
        self.rules = []

    def add_rule(self, rule):
        """Añade una regla de protección al WAF."""
        self.rules.append(rule)
        logging.info(f'Regla añadida: {rule.__name__}')

    def apply_rules(self, request):
        """Aplica todas las reglas al request proporcionado.
        
        Args:
            request (dict): Diccionario que representa una solicitud web con claves 'ip', 'query' y 'content'.
        
        Returns:
            bool: True si la solicitud pasa todas las reglas, False si alguna regla la bloquea.
        """
        for rule in self.rules:
            if not rule(request):
                logging.warning(f'Solicitud bloqueada por la regla: {rule.__name__}')
                return False
        logging.info('Solicitud aprobada por el WAF')
        return True

def block_ip_rule(request):
    """Regla para bloquear solicitudes basadas en la IP."""
    blocked_ips = {"192.168.0.1"}
    return request["ip"] not in blocked_ips

def sql_injection_rule(request):
    """Regla para prevenir ataques de SQL injection."""
    sql_keywords = {"select", "drop", "insert", "delete"}
    return not any(keyword in request["query"].lower() for keyword in sql_keywords)

def xss_rule(request):
    """Regla para prevenir ataques de Cross-Site Scripting (XSS)."""
    return "<script>" not in request["content"].lower()

class LoadBalancer:
    """Clase que representa un balanceador de carga para distribuir tráfico a múltiples servidores."""
    def __init__(self, waf):
        self.waf = waf
        self.servers = []

    def add_server(self, server):
        """Añade un servidor al balanceador de carga."""
        self.servers.append(server)
        logging.info(f'Servidor añadido: {server}')

    def handle_request(self, request):
        """Maneja una solicitud aplicando el WAF antes de distribuirla a un servidor."""
        if self.waf.apply_rules(request):
            server = self.servers[0]  # Simulación de elección de servidor
            logging.info(f'Solicitud enviada al servidor: {server}')
            return server.handle_request(request)
        else:
            logging.warning('Solicitud bloqueada por el WAF')
            return "Request blocked by WAF"

class Server:
    """Clase que representa un servidor web."""
    def __init__(self, id):
        self.id = id

    def handle_request(self, request):
        """Simula el manejo de una solicitud en el servidor."""
        logging.info(f'Servidor {self.id} manejando solicitud con contenido: {request["content"]}')
        return f"Request handled by server {self.id}"

class LoadBalancer:
    def __init__(self):
        self.servers = []
        self.policy = None

    def add_server(self, server: Server):
        """Añade un servidor al balanceador"""
        self.servers.append(server)
        logging.info(f'Servidor añadido: {server.id}')

    def remove_server(self, server: Server):
        """Elimina un servidor del balanceador"""
        self.servers.remove(server)
        logging.info(f'Servidor eliminado: {server.id}')

    def set_policy(self, policy_function):
        """Configura una política de distribución de carga"""
        self.policy = policy_function

    def distribute_request(self):
        """Distribuye una solicitud a un servidor según la política"""
        if self.policy:
            server = self.policy(self.servers)
            server.handle_request()
        else:
            logging.error('No se ha configurado una política de distribución de carga')

class ApplicationLoadBalancer(LoadBalancer):
    """Balanceador de carga de aplicación"""
    pass

class NetworkLoadBalancer(LoadBalancer):
    """Balanceador de carga de red"""
    pass

class ClassicLoadBalancer(LoadBalancer):
    """Balanceador de carga clásico"""
    pass

# Políticas de distribución de carga
def round_robin_policy(servers: List[Server]):
    """Política de distribución round-robin"""
    round_robin_policy.counter = (round_robin_policy.counter + 1) % len(servers)
    return servers[round_robin_policy.counter]
round_robin_policy.counter = -1

def least_connections_policy(servers: List[Server]):
    """Política de distribución de menos conexiones"""
    return min(servers, key=lambda s: s.active_connections)

def ip_hash_policy(servers: List[Server], ip: str):
    """Política de distribución basada en IP hash"""
    index = hash(ip) % len(servers)
    return servers[index]

class LoadBalancerMonitor:
    def __init__(self, load_balancer: LoadBalancer):
        self.load_balancer = load_balancer

    def log_metrics(self):
        """Registra métricas de rendimiento y estadísticas de distribución de carga"""
        total_connections = sum(server.active_connections for server in self.load_balancer.servers)
        logging.info(f'Total de conexiones activas: {total_connections}')
        for server in self.load_balancer.servers:
            logging.info(f'Servidor {server.id} - Conexiones activas: {server.active_connections}')

class TrafficSimulator:
    def __init__(self, load_balancers: List[LoadBalancer]):
        self.load_balancers = load_balancers

    def simulate_traffic(self, duration: int):
        """Simula tráfico de red durante un periodo de tiempo"""
        start_time = time.time()
        while time.time() - start_time < duration:
            for load_balancer in self.load_balancers:
                load_balancer.distribute_request()
            time.sleep(1)

        # Liberar conexiones
        for load_balancer in self.load_balancers:
            for server in load_balancer.servers:
                server.release_connection()

# Crear instancias de servidores
# Crear instancias de servidores iniciales
initial_servers = [Server(id=i) for i in range(3)]

# Crear instancia del grupo de autoescalado y balanceador de carga
auto_scaling_group = AutoScalingGroup(initial_servers, max_servers=5)
load_balancer = LoadBalancer(initial_servers)

# Crear simulador de tráfico
traffic_simulator = TrafficSimulator(load_balancer, auto_scaling_group)

# Simular tráfico web durante 30 segundos
traffic_simulator.simulate_traffic(duration=30)

# Crear un clúster de servidores y un autoescalador
cluster = ServerCluster()
initial_server = Server(id=1, cpu_capacity=100, memory_capacity=100)
cluster.add_server(initial_server)

auto_scaler = AutoScaler(cluster=cluster, cpu_threshold=0.75, memory_threshold=0.75)

# Crear el simulador de tráfico
traffic_simulator = TrafficSimulator(cluster=cluster, auto_scaler=auto_scaler)

# Simular tráfico durante 60 segundos
traffic_simulator.simulate_traffic(duration=60)

# Imprimir el estado final del clúster
logging.info(f'Estado final del clúster: {cluster}')
# Configuración del logger
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

servers = [Server(id=i) for i in range(5)]

# Crear instancias de balanceadores de carga
alb = ApplicationLoadBalancer()
nlb = NetworkLoadBalancer()
clb = ClassicLoadBalancer()

# Añadir servidores a los balanceadores de carga
for server in servers:
    alb.add_server(server)
    nlb.add_server(server)
    clb.add_server(server)

# Configurar políticas de distribución de carga
alb.set_policy(round_robin_policy)
nlb.set_policy(least_connections_policy)
clb.set_policy(lambda servers: ip_hash_policy(servers, ip="192.168.0.1"))

# Crear monitores de balanceadores de carga
alb_monitor = LoadBalancerMonitor(alb)
nlb_monitor = LoadBalancerMonitor(nlb)
clb_monitor = LoadBalancerMonitor(clb)

# Crear simulador de tráfico
traffic_simulator = TrafficSimulator([alb, nlb, clb])

# Simular tráfico de red durante 30 segundos
traffic_simulator.simulate_traffic(duration=30)

# Registrar métricas de rendimiento
alb_monitor.log_metrics()
nlb_monitor.log_metrics()
clb_monitor.log_metrics()

    # Crear y configurar el WAF
    waf = WebApplicationFirewall()
    waf.add_rule(block_ip_rule)
    waf.add_rule(sql_injection_rule)
    waf.add_rule(xss_rule)

    # Crear un balanceador de carga y añadir servidores
    lb = LoadBalancer(waf=waf)
    server1 = Server(id=1)
    server2 = Server(id=2)
    lb.add_server(server1)
    lb.add_server(server2)

    # Simular una solicitud web
    request = {
        "ip": "192.168.0.2",
        "query": "SELECT * FROM users",
        "content": "Hello World"
    }
    response = lb.handle_request(request)
    logging.info(f'Respuesta: {response}')

class PhysicalLayer:
    def transmit(self, data):
        # Simula la transmisión física de bits
        print(f"Transmitiendo bits: {data}")

class DataLinkLayer:
    def __init__(self):
        self.connections = {}

    def add_connection(self, source, destination):
        # Establece una conexión lógica entre dos dispositivos
        self.connections[source] = destination

    def send_frame(self, source, data):
        # Agrega encabezados y envía el marco
        destination = self.connections.get(source)
        if destination:
            print(f"Enviando marco desde {source} a {destination}: {data}")

class NetworkLayer:
    def route_packet(self, source, destination, data):
        # Encamina el paquete a través de la red
        print(f"Encaminando paquete desde {source} a {destination}: {data}")

class TransportLayer:
    def send_segment(self, source, destination, data):
        # Divide los datos en segmentos y agrega números de secuencia
        print(f"Enviando segmento desde {source} a {destination}: {data}")

class ApplicationLayer:
    def send_request(self, data):
        # Crea una solicitud HTTP
        print(f"Enviando solicitud HTTP: {data}")

# Ejemplo de uso
physical = PhysicalLayer()
datalink = DataLinkLayer()
network = NetworkLayer()
transport = TransportLayer()
application = ApplicationLayer()

datalink.add_connection("Navegador", "Servidor")
datalink.send_frame("Navegador", "Datos del navegador")

network.route_packet("Navegador", "Servidor", "Datos de red")

transport.send_segment("Navegador", "Servidor", "Datos de transporte")

application.send_request("GET /index.html HTTP/1.1")

# Configuración de alta disponibilidad y escalabilidad en AWS[^1^][1]

# Definir la infraestructura básica
vpc = create_vpc('mi_vpc')
subnet_publica = create_subnet(vpc, 'subnet_publica')
subnet_privada = create_subnet(vpc, 'subnet_privada')

# Crear instancias EC2 en múltiples zonas de disponibilidad[^2^][2]
instancia_ec2_1 = create_ec2_instance(subnet_publica, 't2.micro', 'ami-12345678')
instancia_ec2_2 = create_ec2_instance(subnet_privada, 't2.micro', 'ami-12345678')

# Configurar Auto Scaling
auto_scaling_group = create_auto_scaling_group([instancia_ec2_1, instancia_ec2_2], min_size=2, max_size=10)

# Configurar Elastic Load Balancer (ELB)
elb = create_elb([instancia_ec2_1, instancia_ec2_2], 'internet-facing')

# Configurar reglas de seguridad
security_group = create_security_group(vpc, 'mi_grupo_seguridad')
add_ingress_rule(security_group, '0.0.0.0/0', 80, 'tcp')  # Permitir tráfico HTTP
add_ingress_rule(security_group, '0.0.0.0/0', 443, 'tcp') # Permitir tráfico HTTPS

# Asociar el grupo de seguridad a las instancias EC2
associate_security_group(instancia_ec2_1, security_group)
associate_security_group(instancia_ec2_2, security_group)

# Configurar almacenamiento compartido con EFS
efs = create_efs(vpc, 'mi_efs')
mount_efs(instancia_ec2_1, efs, '/mnt/efs')
mount_efs(instancia_ec2_2, efs, '/mnt/efs')

# Configurar WAF para proteger la aplicación web[^3^][3]
waf = create_waf('mi_waf')
add_waf_rule(waf, 'SQL_Injection_Rule')
add_waf_rule(waf, 'XSS_Rule')

# Asociar WAF con el ELB
associate_waf_with_elb(waf, elb)

# Configurar monitoreo y alertas
cloudwatch = create_cloudwatch('mi_cloudwatch')
add_alarm(cloudwatch, 'CPU_Utilization', 'GreaterThanThreshold', 80, auto_scaling_group)

# Implementar la aplicación
deploy_application(instancia_ec2_1, 'mi_aplicacion')
deploy_application(instancia_ec2_2, 'mi_aplicacion')

# Verificar la configuración
check_configuration(vpc, elb, auto_scaling_group, security_group, efs, waf, cloudwatch)

