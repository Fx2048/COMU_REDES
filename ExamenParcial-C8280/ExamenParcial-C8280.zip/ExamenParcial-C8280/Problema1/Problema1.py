class handshake(self, cliente,servidor):
      def __init__(self):
          self.paquetes_sincronizados={}
      def cliente(self, paquete, syn,syn-ack, ack):
          cliente.send=paquete
          if paquete == syn:
             self.paquetes_sincronizados['servidor'].append(servidor)
             print (f"Servidor{servidor} asignado a Cliente{cliente}exitosamente.")
             return True
      def servidor(self,paquete,syn,syn-ack,ack):
          if paquete == syn-ack:
              
SyntaxError: invalid syntax
class handshake(self, cliente,servidor):
      def __init__(self):
          self.paquetes_sincronizados={}
      def cliente(self, paquete, syn,syn_ack, ack):
          cliente.send=paquete
          if paquete == syn:
             self.paquetes_sincronizados['servidor'].append(servidor)
             print (f"Servidor{servidor} asignado a Cliente{cliente}exitosamente.")
             return True
      def servidor(self,paquete,syn,syn_ack,ack):
          if paquete == syn_ack:
             self.paquetes_sincronizados['cliente'].append(cliente)
             print (f"Servidor{servidor} asignado a Cliente{cliente}exitosamente.")
             return True
     