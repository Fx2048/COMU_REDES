class VLANManager: # Para indicar la 
      def __init__(self):
          self.vlans={}
      def crear_vlan(self,vlan_id,nombre):
          if vlan_id in self.vlans:
              print(f"Error:Ya existe una VLAN con el ID{vlan_id}")# no se puede aperturar otra id_de VLAN porque estaría repitiendo la que ya existe
              return False
          self.vlans[vlan_id]={'nombre':nombre,'dispositivos':[]}
          print(f"VLAN{vlan_id}-'{nombre}'creado exitosamente")
          return True
      def asignar_dispositivo(self,vlan_id,dispositivo):# se asigna al dispositivo
          if vlan_id not in self.vlans:
              print(f"Error no se encontro la vlan con id{vlan_id}")
              return False
          if dispositivo in self.vlans[vlan_id]['dispositivos']:
             print(f"erorr: el dispositivo{dispositivo}ya esta asigniadoa la VLAN{vlan_id}")
             return False
          self.vlans[vlan_id]['dispositivos'].append(dispositivo)
          print(f"Dispositivo{dispositivo} asingado a VLAN {vlan_id}exitosamente")
          return TRUE
      def change_vlan(self,vlan_id,nombre): # Modificar vlan name existente, cerciorándonos, que si existe , entonces, realizar cualquier cambio y manejar adecuada mente los casos en que la soliciutd no exista.
          if vlan_id==none or vlan_id= self.vlans.items():
             return(def crear_vlan(self,vlan_id,nombre))
          else: 

      def search(self,vlan_id,nombre): # búsqueda de un vlan asignado en dispositivo según su dirección Mac
          if vlan id ==  vlan_id in c:
          return vlan_id
      def export (self,vlan_id,nombre,file): #exportar configuracion
          for configurate export_file= file.config(vlan_id)
          return True
      def import(self, vlan_id,nombre,file): # importar configuración de un archivo
          for configurate import_file= file.config(vlan_id)
          return True

      def listar_vlans(self):# se enlista una vlan
          if not self.vlans:
                 print ("no hay vlans registradaas")
                 return
          for vlan_id,info in self.vlans.items():
              print(f"VLAN ID:{vlan_id},nombre:{info['nombre']},Dispositivos:{info['dispositivos']}")
      def eliminar_vlan(self,vlan_id):
          if vlan_id not in self.vlans:
             print(f"error no se encontro la vlan con id {vlan_id}")
             return False
          del self.vlans[vlan_id]
          print(f"VLAN{vlan_id}eliminado exitosaemnte")
          return True
      if __name__ =="__main__":
         manager=VLANManager()
         manager.crear_vlan(1,"Produccion")
         manager.crear_vlan(2,"Desarrlo")
         manager.asignar_dispositivo(1,"00:1A:2B:3C:4D:5E")
         manager.asignar_dispositivo(2,"00:1A:2B:3C:4D:5E:6F")
         manager.listar_vlans()
         manager.eliminar_vlan(2)
         manager.listar_vlans()
         manager.search(1,"Produccion",docx.py)
         manager.import(1,"Produccion",docx.py)