import random  # Importa el módulo random para generar números aleatorios.
import time  # Importa el módulo time para trabajar con intervalos de tiempo.
import threading  # Importa el módulo threading para trabajar con hilos.

class VirtualMachine:  # Define la clase VirtualMachine.
    def __init__(self, vm_id):  # Constructor que inicializa una VM con un ID.
        self.vm_id = vm_id  # Asigna el ID de la VM.
        self.state = "STOPPED"  # Estado inicial de la VM, puede ser STOPPED o RUNNING.
        self.cpu_usage = 0  # Uso de CPU de la VM, inicialmente 0.
        self.memory_usage = 0  # Uso de memoria de la VM, inicialmente 0.

    def start(self):  # Método para iniciar la VM.
        if self.state == "STOPPED":  # Solo inicia si la VM está detenida.
            self.state = "RUNNING"  # Cambia el estado a RUNNING.
            print(f"VM {self.vm_id}: Iniciada")  # Imprime que la VM ha sido iniciada.

    def stop(self):  # Método para detener la VM.
        if self.state == "RUNNING":  # Solo detiene si la VM está corriendo.
            self.state = "STOPPED"  # Cambia el estado a STOPPED.
            self.cpu_usage = 0  # Resetea el uso de CPU a 0.
            self.memory_usage = 0  # Resetea el uso de memoria a 0.
            print(f"VM {self.vm_id}: Detenida")  # Imprime que la VM ha sido detenida.

    def restart(self):  # Método para reiniciar la VM.
        if self.state == "RUNNING":  # Solo reinicia si la VM está corriendo.
            self.stop()  # Detiene la VM.
            time.sleep(1)  # Espera 1 segundo.
            self.start()  # Inicia la VM.
            print(f"VM {self.vm_id}: Reiniciada")  # Imprime que la VM ha sido reiniciada.

    def simulate_failure(self):  # Método para simular fallos en la VM.
        if self.state == "RUNNING" and random.random() < 0.1:  # 10% de probabilidad de fallo.
            self.state = "STOPPED"  # Cambia el estado a STOPPED.
            self.cpu_usage = 0  # Resetea el uso de CPU a 0.
            self.memory_usage = 0  # Resetea el uso de memoria a 0.
            print(f"VM {self.vm_id}: Fallo simulado")  # Imprime que la VM ha fallado.

class Hypervisor:  # Define la clase Hypervisor.
    def __init__(self):  # Constructor que inicializa el hipervisor.
        self.vms = {}  # Diccionario para almacenar las VMs.

    def create_vm(self, vm_id):  # Método para crear una nueva VM.
        if vm_id not in self.vms:  # Solo crea la VM si no existe ya.
            self.vms[vm_id] = VirtualMachine(vm_id)  # Crea una nueva VM y la añade al diccionario.
            print(f"Hypervisor: VM {vm_id} creada")  # Imprime que la VM ha sido creada.

    def start_vm(self, vm_id):  # Método para iniciar una VM.
        if vm_id in self.vms:  # Solo inicia si la VM existe.
            self.vms[vm_id].start()  # Llama al método start de la VM.

    def stop_vm(self, vm_id):  # Método para detener una VM.
        if vm_id in self.vms:  # Solo detiene si la VM existe.
            self.vms[vm_id].stop()  # Llama al método stop de la VM.

    def restart_vm(self, vm_id):  # Método para reiniciar una VM.
        if vm_id in self.vms:  # Solo reinicia si la VM existe.
            self.vms[vm_id].restart()  # Llama al método restart de la VM.

    def allocate_resources(self, vm_id, cpu, memory):  # Método para asignar recursos a una VM.
        if vm_id in self.vms and self.vms[vm_id].state == "RUNNING":  # Solo asigna si la VM está corriendo.
            self.vms[vm_id].cpu_usage = cpu  # Asigna el uso de CPU.
            self.vms[vm_id].memory_usage = memory  # Asigna el uso de memoria.
            print(f"Hypervisor: Recursos asignados a VM {vm_id} - CPU: {cpu}%, Memoria: {memory}MB")  # Imprime los recursos asignados.

    def balance_load(self):  # Método para balancear la carga entre las VMs.
        total_cpu_usage = sum(vm.cpu_usage for vm in self.vms.values() if vm.state == "RUNNING")  # Calcula el uso total de CPU.
        total_memory_usage = sum(vm.memory_usage for vm in self.vms.values() if vm.state == "RUNNING")  # Calcula el uso total de memoria.
        num_running_vms = sum(1 for vm in self.vms.values() if vm.state == "RUNNING")  # Cuenta las VMs corriendo.

        if num_running_vms > 0:  # Solo balancea si hay VMs corriendo.
            avg_cpu = total_cpu_usage // num_running_vms  # Calcula el uso promedio de CPU.
            avg_memory = total_memory_usage // num_running_vms  # Calcula el uso promedio de memoria.

            for vm in self.vms.values():  # Asigna los valores promedio a cada VM.
                if vm.state == "RUNNING":
                    vm.cpu_usage = avg_cpu  # Asigna el uso promedio de CPU.
                    vm.memory_usage = avg_memory  # Asigna el uso promedio de memoria.

            print(f"Hypervisor: Balanceo de carga - CPU promedio: {avg_cpu}%, Memoria promedio: {avg_memory}MB")  # Imprime el balanceo de carga.

    def simulate_failures_and_recover(self):  # Método para simular fallos y recuperarlos automáticamente.
        for vm in self.vms.values():  # Itera sobre cada VM.
            vm.simulate_failure()  # Simula fallos en la VM.
            if vm.state == "STOPPED":  # Si la VM ha fallado.
                print(f"Hypervisor: Detectando fallo en VM {vm.vm_id}, intentando recuperación...")  # Imprime que se ha detectado un fallo.
                self.start_vm(vm.vm_id)  # Intenta reiniciar la VM.

def simulate_operations():  # Función para simular operaciones del hipervisor.
    hypervisor = Hypervisor()  # Crea una instancia del hipervisor.
    
    # Crear y manejar VMs
    for i in range(5):  # Crea 5 VMs.
        hypervisor.create_vm(f"VM_{i}")

    # Iniciar todas las VMs
    for vm_id in hypervisor.vms:  # Inicia todas las VMs.
        hypervisor.start_vm(vm_id)

    # Asignar recursos
    for vm_id in hypervisor.vms:  # Asigna recursos aleatorios a cada VM.
        hypervisor.allocate_resources(vm_id, random.randint(10, 50), random.randint(512, 2048))

    # Balancear carga
    hypervisor.balance_load()  # Balancea la carga entre las VMs.

    # Simular fallos y recuperación automática
    while True:  # Bucle infinito para simular continuamente.
        hypervisor.simulate_failures_and_recover()  # Simula fallos y recuperación.
        time.sleep(5)  # Espera 5 segundos entre cada simulación de fallos.

if __name__ == "__main__":  # Punto de entrada del script.
    simulation_thread = threading.Thread(target=simulate_operations)  # Crea un hilo para simular operaciones.
    simulation_thread.start()  # Inicia el hilo de simulación.
