import random
import time
import threading

class Server:  # Definición de la clase Server
    def __init__(self, port):
        self.port = port  # Puerto del servidor
        self.clients = {}  # Diccionario para almacenar el estado de los clientes

    def receive_syn(self, client_id):  # Método para recibir un paquete SYN
        print(f"Servidor: Recibido SYN de {client_id}")  # Mensaje de recepción de SYN
        if random.random() < 0.1:  # Simulación de pérdida de paquetes con 10% de probabilidad
            print(f"Servidor: SYN perdido de {client_id}")  # Mensaje de pérdida de SYN
            return False  # Indica que el SYN se perdió
        self.clients[client_id] = "SYN_RECEIVED"  # Actualiza el estado del cliente a SYN_RECEIVED
        return True  # Indica que el SYN se recibió correctamente

    def send_syn_ack(self, client_id):  # Método para enviar un paquete SYN-ACK
        if client_id in self.clients and self.clients[client_id] == "SYN_RECEIVED":  # Verifica si el cliente ha enviado SYN
            print(f"Servidor: Enviando SYN-ACK a {client_id}")  # Mensaje de envío de SYN-ACK
            if random.random() < 0.1:  # Simulación de pérdida de paquetes con 10% de probabilidad
                print(f"Servidor: SYN-ACK perdido de {client_id}")  # Mensaje de pérdida de SYN-ACK
                return False  # Indica que el SYN-ACK se perdió
            self.clients[client_id] = "SYN-ACK_SENT"  # Actualiza el estado del cliente a SYN-ACK_SENT
            return True  # Indica que el SYN-ACK se envió correctamente
        return False  # Indica que el SYN-ACK no se envió

    def receive_ack(self, client_id):  # Método para recibir un paquete ACK
        if client_id in self.clients and self.clients[client_id] == "SYN-ACK_SENT":  # Verifica si el cliente ha enviado SYN-ACK
            print(f"Servidor: Recibido ACK de {client_id}")  # Mensaje de recepción de ACK
            if random.random() < 0.1:  # Simulación de pérdida de paquetes con 10% de probabilidad
                print(f"Servidor: ACK perdido de {client_id}")  # Mensaje de pérdida de ACK
                return False  # Indica que el ACK se perdió
            self.clients[client_id] = "CONNECTED"  # Actualiza el estado del cliente a CONNECTED
            print(f"Servidor: {client_id} conectado")  # Mensaje de cliente conectado
            return True  # Indica que el ACK se recibió correctamente
        return False  # Indica que el ACK no se recibió
class Client:  # Definición de la clase Client
    def __init__(self, server, client_id):  # Inicialización del cliente con referencia al servidor y una ID de cliente
        self.server = server  # Referencia al servidor
        self.client_id = client_id  # ID del cliente
        self.state = "CLOSED"  # Estado inicial del cliente
        self.timeout = 1  # Tiempo de espera (timeout) para reintentar

    def connect(self):  # Método para conectar el cliente al servidor
        while self.state != "CONNECTED":  # Bucle hasta que el estado sea CONNECTED
            if self.state == "CLOSED":  # Si el estado es CLOSED
                print(f"Cliente {self.client_id}: Enviando SYN")  # Mensaje de envío de SYN
                if self.server.receive_syn(self.client_id):  # Intenta enviar SYN al servidor
                    self.state = "SYN_SENT"  # Actualiza el estado a SYN_SENT
            elif self.state == "SYN_SENT":  # Si el estado es SYN_SENT
                print(f"Cliente {self.client_id}: Esperando SYN-ACK")  # Mensaje de espera de SYN-ACK
                if self.server.send_syn_ack(self.client_id):  # Intenta recibir SYN-ACK del servidor
                    print(f"Cliente {self.client_id}: Recibido SYN-ACK")  # Mensaje de recepción de SYN-ACK
                    print(f"Cliente {self.client_id}: Enviando ACK")  # Mensaje de envío de ACK
                    if self.server.receive_ack(self.client_id):  # Intenta enviar ACK al servidor
                        self.state = "CONNECTED"  # Actualiza el estado a CONNECTED
                        print(f"Cliente {self.client_id}: Conectado")  # Mensaje de cliente conectado
                else:
                    time.sleep(self.timeout)  # Espera antes de reintentar
            else:
                time.sleep(self.timeout)  # Espera antes de reintentar
def simulate():  # Función para simular el proceso
    server = Server(port=12345)  # Crea una instancia del servidor con el puerto 12345
    
    # Creación de múltiples clientes
    clients = [Client(server, f"Cliente_{i}") for i in range(5)]  # Crea una lista de 5 clientes

    threads = []  # Lista para almacenar los hilos
    for client in clients:  # Para cada cliente en la lista de clientes
        thread = threading.Thread(target=client.connect)  # Crea un hilo para la conexión del cliente
        threads.append(thread)  # Añade el hilo a la lista de hilos
        thread.start()  # Inicia el hilo

    for thread in threads:  # Para cada hilo en la lista de hilos
        thread.join()  # Espera a que el hilo termine

if __name__ == "__main__":  # Punto de entrada del programa
    simulate()  # Llama a la función simulate para iniciar la simulación
