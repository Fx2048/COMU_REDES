import time
import threading

class ARPTable:
    def __init__(self):
        self.table = {}  # Diccionario para almacenar la tabla ARP
        self.lock = threading.Lock()  # Lock para la concurrencia
        self.max_age = 60  # Tiempo máximo de vida de una entrada en segundos

    def add_entry(self, ip, mac):  # Método para agregar una entrada a la tabla ARP
        with self.lock:
            self.table[ip] = {'mac': mac, 'timestamp': time.time()}
            print(f"Entrada ARP añadida: IP={ip}, MAC={mac}")

    def remove_entry(self, ip):  # Método para eliminar una entrada de la tabla ARP
        with self.lock:
            if ip in self.table:
                del self.table[ip]
                print(f"Entrada ARP eliminada: IP={ip}")

    def get_mac(self, ip):  # Método para obtener la dirección MAC correspondiente a una dirección IP
        with self.lock:
            entry = self.table.get(ip)
            if entry:
                return entry['mac']
            else:
                return None

    def aging(self):  # Método para eliminar entradas antiguas de la tabla ARP
        while True:
            with self.lock:
                current_time = time.time()
                for ip in list(self.table.keys()):
                    if current_time - self.table[ip]['timestamp'] > self.max_age:
                        del self.table[ip]
                        print(f"Entrada ARP envejecida eliminada: IP={ip}")
            time.sleep(10)  # Revisa cada 10 segundos

    def send_arp_request(self, ip):  # Método para enviar una solicitud ARP
        print(f"Solicitud ARP enviada para IP: {ip}")
        # En una red real, aquí se enviaría un paquete ARP. Simulamos una respuesta.
        mac = self.simulate_arp_response(ip)
        if mac:
            self.add_entry(ip, mac)
            return mac
        return None

    def simulate_arp_response(self, ip):  # Método para simular una respuesta ARP
        # Simulamos una respuesta ARP con una dirección MAC ficticia
        simulated_mac = f"00:00:00:00:00:{int(ip.split('.')[-1]):02x}"
        print(f"Respuesta ARP simulada recibida para IP: {ip}, MAC: {simulated_mac}")
        return simulated_mac

# Función principal para simular el funcionamiento de la tabla ARP
def simulate_arp():
    arp_table = ARPTable()

    # Iniciar el proceso de envejecimiento en un hilo separado
    aging_thread = threading.Thread(target=arp_table.aging)
    aging_thread.daemon = True
    aging_thread.start()

    # Simular la adición de entradas a la tabla ARP
    arp_table.add_entry("192.168.1.1", "00:0a:95:9d:68:16")
    arp_table.add_entry("192.168.1.2", "00:0a:95:9d:68:17")

    # Intentar obtener una dirección MAC existente
    mac = arp_table.get_mac("192.168.1.1")
    if mac:
        print(f"Dirección MAC para 192.168.1.1: {mac}")
    else:
        print("No se encontró la dirección MAC para 192.168.1.1")

    # Intentar obtener una dirección MAC no existente y enviar solicitud ARP
    mac = arp_table.get_mac("192.168.1.3")
    if mac:
        print(f"Dirección MAC para 192.168.1.3: {mac}")
    else:
        print("No se encontró la dirección MAC para 192.168.1.3, enviando solicitud ARP")
        mac = arp_table.send_arp_request("192.168.1.3")
        if mac:
            print(f"Dirección MAC para 192.168.1.3: {mac}")
        else:
            print("No se recibió respuesta ARP para 192.168.1.3")

    # Simular eliminación de una entrada
    arp_table.remove_entry("192.168.1.2")

if __name__ == "__main__":
    simulate_arp()
